import requests

# endpoints
endpoint="http://localhost:8000/api/products/"

get_response=requests.post(endpoint,json={'title':"IpadMini"})

#Printing the data that is echoed back

print(get_response.json())
