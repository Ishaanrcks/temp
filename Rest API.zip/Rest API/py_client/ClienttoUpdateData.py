'''Generic view to update'''
import requests
endpoint="http://localhost:8000/api/products/22/update"
get_response=requests.put(endpoint,json={'title':"IPhone 6Se Updated", 'price':41000})
# print(get_response.json())