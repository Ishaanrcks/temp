'''Genereic view to destroy'''
import requests
endpoint="http://localhost:8000/api/products/20/destroy"
get_response=requests.delete(endpoint)
# print(get_response.json())