import requests

# endpoint="https://github.com/"
# endpoint="https://httpbin.org/"
'''The above two endpoints are examples of simple websites so on making request to their server as expected they gave us HTML code that they used to give to the browser'''
endpoint="https://httpbin.org/anything" # This endpoint will too echoback anything that we will send to it
# This endpoint is the endpoint of an api so on requesting the API it will return us a JSON response
# A JSON response is similar to python dictionary JSON is Javascript Object Notation

response=requests.get(endpoint) # It will extract simple text response that is the body of the response
print(response.text)
'''
OUTPUT: TYPE STR
{
  "args": {},
  "data": "",
  "files": {},
  "form": {},
  "headers": {
    "Accept": "*/*",
    "Accept-Encoding": "gzip, deflate",
    "Host": "httpbin.org",
    "User-Agent": "python-requests/2.32.3",
    "X-Amzn-Trace-Id": "Root=1-6684fe5a-286305e61c890c94396f7115"      
  },
  "json": null,
  "method": "GET",
  "origin": "152.59.102.192",
  "url": "https://httpbin.org/anything"
}

'''


# For getting the response as a python dictionary instead of JSON we will use the method json()
print(response.json())
'''
OUTPUT: TYPE DICTIONARY
{'args': {}, 'data': '', 'files': {}, 'form': {}, 'headers': {'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate', 'Host': 'httpbin.org', 'User-Agent': 'python-requests/2.32.3', 'X-Amzn-Trace-Id': 'Root=1-66850138-01a5f8ba5a2893c419d68bab'}, 'json': None, 'method': 'GET', 'origin': '152.59.102.192', 'url': 'https://httpbin.org/anything'}
'''


response1=requests.get(endpoint,json={'query':'What is your name?'})#Here we are giving json data to the api so its going to exho back json data. And we knew this as a fact as the context type has changed to application/json
print(response1.json())

response1=requests.get(endpoint,data={'query':'What is your name?'})#Here we are giving json data to the api so its going to exho back json data. And we knew this as a fact as the context type has changed to form as the data is recieved as form data
print(response1.json())