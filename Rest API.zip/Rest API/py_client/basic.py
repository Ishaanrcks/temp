''''
In this File we are trying to make a client so that we can test the api that will be made by us using django'''
import requests
import json
endpoint="http://127.0.0.1:8001/"
endpoint="http://localhost:8000/api/"#This endpoint is similar to the above one
'''
When we haven't made an api using django at that point we were getting simply the HTML code of the page as we are simply making the HTTP Request to the server and the API wasn't configured so we didn't get JSON'''
get_response=requests.post(endpoint,json={'title':'MacbookAir'})
print(get_response.json())

#There are times that you may want to send data that is not form-encoded. If you pass in a string instead of a dict in data parameter of requests.get(), that data will be posted directly.Please note that the above code will NOT add the Content-Type header (so in particular it will NOT set it to application/json).


