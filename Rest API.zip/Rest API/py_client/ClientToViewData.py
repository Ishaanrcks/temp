'''This client is to test the view product_alt_view(request,pk=None).
That is using function based viewd yo retrivr detail or list view'''
import requests
endpoint="http://localhost:8000/api/products/9"
get_response=requests.post(endpoint)
print(get_response.json())