'''This client is to test the view product_alt_view(request,pk=None).
That is using function based viewto add data to the model'''
import requests
endpoint="http://localhost:8000/api/products/"
get_response=requests.post(endpoint,json={'title':"TOYS CABLE", 'price':400})
# print(get_response.json())