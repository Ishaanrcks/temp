from django.contrib import admin

from .models import Products
# Register your models here.
class Products_adm(admin.ModelAdmin):
    list_display=('id','title','content','price')
admin.site.register(Products,Products_adm)