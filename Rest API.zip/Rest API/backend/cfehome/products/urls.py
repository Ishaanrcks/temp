from django.urls import path , include

from . import views
urlpatterns = [
    path('',views.ProductListCreateAPIView.as_view()),
    path('<int:pk>',views.ProductDetailAPIView.as_view()),
    #  path('<int:id>',views.ProductListAPIView.as_view()),
    # path('<int:pk>',views.ProductDetailAPIView.as_view()),
    # path('<str:title>',views.ProductDetailAPIView.as_view()),
    path('<int:id>/destroy',views.ProductDestroyAPIView.as_view()),
    path('<int:id>/update',views.ProductUpdateAPIView.as_view()),
        # The below two urls will be used for the view product_alt_view(request,pk=None):
    #  path('',views.product_alt_view),

    # Now we will use a single class based view for all our routes
    # path('',views.ProductMixinView.as_view()),
    # path('<int:id>',views.ProductMixinView.as_view()),
    #  path('<int:id>',views.ProductMixinView.as_view()),
    path('auth/',include('rest_framework.urls',namespace='rest_framework'))
]
