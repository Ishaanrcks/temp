from rest_framework import generics , mixins , permissions, authentication #Now we will try using permission in our generic API Views
from .models import Products
from .serialisers import ProductSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response 
from django.http import Http404
from django.shortcuts import get_object_or_404
# Class-based view

class ProductListCreateAPIView(generics.ListCreateAPIView):
    queryset=Products.objects.all()
    serializer_class=ProductSerializer
    authentication_classes=[authentication.BasicAuthentication]
    permission_classes=[permissions.DjangoModelPermissions]
    #By listing the permission class in the permission_classes we can list out what are the permissions our user is having. If no user has been authenticated and the permission are not alloted to him then in that case he would not be able to see the data either from the browser or through the client. To see the data after including the permission classes we would either need to login as a super user and see it pn browser but depite of being logged in we would not be able to see anything on the output if we request data through a client who didn't had valid authorization token.
    # IsAuthenticated will allow a user all the permission if he has authenticated an instance of itself of itself in the user model
    # IsAuthenticatedOrReadOnly will allow anyone if they access the API using get mothod (not post) and with Generic API View that allows the finctionality of reading for example ListAPIView/ListCreateAPIView but not CreateAPIView
    def perform_create(self, serializer):
        content=serializer.validated_data.get('content') or None
        if content is None:
            content="Sorry No Content for this product"
        serializer.save(content=content)
class ProductDetailAPIView(generics.RetrieveAPIView):
    queryset=Products.objects.all()
    serializer_class=ProductSerializer
    authentication_classes=[authentication.BasicAuthentication]
    permission_classes=[permissions.DjangoModelPermissions]
    # lookup_field='title' The entities should be unique while using custom lookup_fields and also the fields should be there in the model as well as the serializer
    # The default lookup_field is the primary key lookup_field='pk'

#ListAPIView

class ProductListAPIView(generics.ListAPIView):
    queryset=Products.objects.all()
    serializer_class=ProductSerializer
    def post(self, request,*args,**kwargs):# The post function defines will help us to add a more HTTP Request Method through which our ListAPIView can be accessed
    
        return self.list(request,*args, **kwargs)


# Delete API View
class ProductDestroyAPIView(generics.DestroyAPIView):
    queryset=Products.objects.all()
    serializer_class=ProductSerializer
    authentication_classes=[authentication.BasicAuthentication]
    permission_classes=[permissions.DjangoModelPermissions]
    lookup_field='id'
    def perform_destroy(self, instance):
        super().perform_destroy(instance)
# Update API View

class ProductUpdateAPIView(generics.UpdateAPIView):
    queryset=Products.objects.all()
    serializer_class=ProductSerializer
    lookup_field='id'
    def perform_update(self, serializer):
        serializer.save()


# Function based Views
@api_view(["POST","GET"])
def product_alt_view(request,pk=None):
    method=request.method

    if (method=="GET"):
        if pk is not None:
            # detail view
            # query=Products.objects.filter(id=pk)
         
            # if not query.exists():
            #     raise Http404("The Product is doesn't exist")
            # data=ProductSerializer(query,many=True).data
            # return Response(data)
            # This is pure basic method
            # For now we will use this method
            obj = get_object_or_404(Products,pk=pk)
            data=ProductSerializer(obj).data
            return Response(data)
        # List Detail
        query=Products.objects.all()
        data=ProductSerializer(query,many=True).data
        return Response(data)
    # We used this approach to add data in a serialized way in the database
    if method=='POST':
        serializer=ProductSerializer(data=request.data)
       
        if serializer.is_valid(raise_exception=True): 
            content=serializer.validated_data.get('content') or None
            if content is None:
                content="Sorry No Content for this Product"
            serializer.save(content=content)
            return Response(serializer.data)
    
    
  
    

# Now We will try to create a class based view which can handle all the generic views alone

class ProductMixinView(generics.GenericAPIView,                              
                       mixins.ListModelMixin,         # As we extended this mixin as a result of which we are able to use query_set and Serialiser Class            
                       mixins.CreateModelMixin,
                       mixins.RetrieveModelMixin):    # As we extended this mixin as a result of which we are able to use lookup_field
    queryset=Products.objects.all()
    serializer_class=ProductSerializer
    lookup_field='id'

    # In function based views we created conditions to deal with different request methods as we used request method type to check what type of operation should be performed and what should be served

    def get(self, request,*args,**kwargs):# The get function defines that what will happen in case a GET HTTP request is made to the server
        #Our kwargs contains the id if we send it through the url that is by get method through client or browser
        # print('hi',kwargs)
     
        id=kwargs.get('id')
        if id is not None:
            return self.retrieve(request,*args, **kwargs)
        return self.list(request,*args, **kwargs)
    # We can use the similar method if we want to add the way how request and want to add some more HTTP request method to is being made to our generic API views
    

    def post(self,request,*args, **kwargs):
        return self.create(request,*args, **kwargs)
    # As the mixin class extends the generic class so we can use the perform_create function here

    def perform_create(self, serializer):
        content=serializer.validated_data.get('content') or None
        if content is None:
            content="Sorry No Content   "
        serializer.save(content=content)
