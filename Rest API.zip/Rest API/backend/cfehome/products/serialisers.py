from rest_framework import serializers
from .models import Products

class ProductSerializer(serializers.ModelSerializer):
    SP=serializers.SerializerMethodField(read_only=True)
    class Meta :
        model = Products
        fields=['title','content','price','SP']
    def get_SP(self,obj):
        try:
            return obj.sale_price
        except:
            return None

        