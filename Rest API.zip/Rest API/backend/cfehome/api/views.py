from django.shortcuts import render
from products.models import Products
from products.serialisers import ProductSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.http import JsonResponse
import json
from django.forms.models import model_to_dict
# Create your views here.
@api_view(["POST","GET"])
def ApiHome(request):
    serializer=ProductSerializer(data=request.data)
   
    if serializer.is_valid(raise_exception=True):
        instance=serializer.save() 
        return Response(serializer.data)
    
    
  